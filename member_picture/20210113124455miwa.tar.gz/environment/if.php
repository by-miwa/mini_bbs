<?php
$num = 6
$even_num = [];
$odd_num = [];

function sort_number($num){
    
    global $even_num, $odd_num;
    
    if($num % 2 == 0){
        print("numは10より大きい");
        array_push($even_num, $num);
    }else{
        array_push($odd_num, $num);
    }
}
?>