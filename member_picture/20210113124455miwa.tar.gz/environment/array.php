<?php
$data = [];
array_push($data, "samurai");
print($data[0]."\n");
?>