<?php
$name = "侍太郎";
print($name);
?>