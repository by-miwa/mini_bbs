<?php
class Hoge
{
    function __construct(){
        $this->name = "大泉";
        $this->age = 46;
    }
}
?>