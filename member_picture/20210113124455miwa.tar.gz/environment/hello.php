<?php
print('Hello World');
?>